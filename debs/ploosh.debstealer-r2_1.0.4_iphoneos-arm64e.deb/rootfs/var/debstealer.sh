#!/var/jb/usr/bin/bash

for i in "$@"; do
    if [[ $i == *.deb ]]; then
        cp "$i" "/var/mobile/debs"
    fi
done

/var/jb/usr/bin/dpkg.debstealer "$@"
